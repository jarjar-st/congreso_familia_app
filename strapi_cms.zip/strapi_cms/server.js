
const strapi = require('strapi');
strapi().start();